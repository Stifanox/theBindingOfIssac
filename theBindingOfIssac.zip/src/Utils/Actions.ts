import { Actions } from "./Interfaces";

export const MovementActionObject:Actions = {
    UP:false,
    DOWN:false,
    LEFT:false,
    RIGHT:false,
}

export const ShotActionObject:Actions = {
    UP:false,
    DOWN:false,
    LEFT:false,
    RIGHT:false,
}